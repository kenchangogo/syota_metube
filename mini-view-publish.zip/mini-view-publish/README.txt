mini-view — 公開用ファイル

このサイトはYouTubeの公式埋め込みプレイヤーを使う静的なページです。学校やネットワークのアクセス制限を回避する機能・プロキシ機能は含みません。

GitHub Pagesで公開する手順
1. GitHubで新しいリポジトリを作成します（GitHub FreeならPublicにします）。
2. このフォルダー内の index.html をリポジトリの一番上（root）にアップロードして commit します。
3. リポジトリの Settings → Pages を開き、Build and deployment の Source で Deploy from a branch を選びます。
4. Branch を main、folder を /(root) にして Save します。
5. Pages設定に表示されるURLから公開されたページを開きます。反映には数分かかることがあります。

注意:
- GitHub Pagesで公開したページはインターネット上で誰でも見られる場合があります。個人情報を含めないでください。
- 学校のネットワークでYouTubeや埋め込み再生がブロックされている場合、このページでも再生できないことがあります。
